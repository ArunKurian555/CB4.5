using System;
using System.Collections.Generic;
using System.Linq;
using Crestron.SimplSharpPro.DeviceSupport;
using Crestron.SimplSharpPro;

namespace CBlink
{
    public interface IZonerename
    {
        object UserObject { get; set; }

        event EventHandler<UIEventArgs> Zoneflag1;
        event EventHandler<UIEventArgs> Zoneflag2;
        event EventHandler<UIEventArgs> Zoneflag3;
        event EventHandler<UIEventArgs> Zoneflag4;
        event EventHandler<UIEventArgs> Zoneflag5;
        event EventHandler<UIEventArgs> Zoneflag6;
        event EventHandler<UIEventArgs> Zoneflag7;
        event EventHandler<UIEventArgs> Zoneflag8;
        event EventHandler<UIEventArgs> Zoneflag9;
        event EventHandler<UIEventArgs> Zoneflag10;
        event EventHandler<UIEventArgs> Zoneflag11;
        event EventHandler<UIEventArgs> Zoneflag12;
        event EventHandler<UIEventArgs> Zoneflag13;
        event EventHandler<UIEventArgs> Zoneflag14;
        event EventHandler<UIEventArgs> Zoneflag15;
        event EventHandler<UIEventArgs> Zoneflag16;
        event EventHandler<UIEventArgs> Zoneflag17;
        event EventHandler<UIEventArgs> Zoneflag18;
        event EventHandler<UIEventArgs> Zoneflag19;
        event EventHandler<UIEventArgs> Zoneflag20;
        event EventHandler<UIEventArgs> Zoneflag21;
        event EventHandler<UIEventArgs> Zoneflag22;
        event EventHandler<UIEventArgs> Zoneflag23;
        event EventHandler<UIEventArgs> Zoneflag24;
        event EventHandler<UIEventArgs> Zoneflag25;
        event EventHandler<UIEventArgs> Zoneflag26;
        event EventHandler<UIEventArgs> Zoneflag27;
        event EventHandler<UIEventArgs> Zoneflag28;
        event EventHandler<UIEventArgs> Zoneflag29;
        event EventHandler<UIEventArgs> Zoneflag30;
        event EventHandler<UIEventArgs> Zoneflag31;
        event EventHandler<UIEventArgs> Zoneflag32;
        event EventHandler<UIEventArgs> Zoneflag33;
        event EventHandler<UIEventArgs> Zoneflag34;
        event EventHandler<UIEventArgs> Zoneflag35;
        event EventHandler<UIEventArgs> Zoneflag36;
        event EventHandler<UIEventArgs> Zoneflag37;
        event EventHandler<UIEventArgs> Zoneflag38;
        event EventHandler<UIEventArgs> Zoneflag39;
        event EventHandler<UIEventArgs> Zoneflag40;
        event EventHandler<UIEventArgs> Zoneflag41;
        event EventHandler<UIEventArgs> Zoneflag42;
        event EventHandler<UIEventArgs> Zoneflag43;
        event EventHandler<UIEventArgs> Zoneflag44;
        event EventHandler<UIEventArgs> Zoneflag45;
        event EventHandler<UIEventArgs> Zoneflag46;
        event EventHandler<UIEventArgs> Zoneflag47;
        event EventHandler<UIEventArgs> Zoneflag48;
        event EventHandler<UIEventArgs> Zoneflag49;
        event EventHandler<UIEventArgs> Zoneflag50;
        event EventHandler<UIEventArgs> Zoneflag51;
        event EventHandler<UIEventArgs> Zoneflag52;
        event EventHandler<UIEventArgs> Zoneflag53;
        event EventHandler<UIEventArgs> Zoneflag54;
        event EventHandler<UIEventArgs> Zoneflag55;
        event EventHandler<UIEventArgs> Zoneflag56;
        event EventHandler<UIEventArgs> Zoneflag57;
        event EventHandler<UIEventArgs> Zoneflag58;
        event EventHandler<UIEventArgs> Zoneflag59;
        event EventHandler<UIEventArgs> Zoneflag60;
        event EventHandler<UIEventArgs> Zoneflag61;
        event EventHandler<UIEventArgs> Zoneflag62;
        event EventHandler<UIEventArgs> Zoneflag63;
        event EventHandler<UIEventArgs> Zoneflag64;
        event EventHandler<UIEventArgs> Zoneflag65;
        event EventHandler<UIEventArgs> Zoneflag66;
        event EventHandler<UIEventArgs> Zoneflag67;
        event EventHandler<UIEventArgs> Zoneflag68;
        event EventHandler<UIEventArgs> Zoneflag69;
        event EventHandler<UIEventArgs> Zoneflag70;
        event EventHandler<UIEventArgs> Zoneflag71;
        event EventHandler<UIEventArgs> Zoneflag72;
        event EventHandler<UIEventArgs> Zoneflag73;
        event EventHandler<UIEventArgs> Zoneflag74;
        event EventHandler<UIEventArgs> Zoneflag75;
        event EventHandler<UIEventArgs> Zoneflag76;
        event EventHandler<UIEventArgs> Zoneflag77;
        event EventHandler<UIEventArgs> Zoneflag78;
        event EventHandler<UIEventArgs> Zoneflag79;
        event EventHandler<UIEventArgs> Zoneflag80;
        event EventHandler<UIEventArgs> Zoneflag81;
        event EventHandler<UIEventArgs> Zoneflag82;
        event EventHandler<UIEventArgs> Zoneflag83;
        event EventHandler<UIEventArgs> Zoneflag84;
        event EventHandler<UIEventArgs> Zoneflag85;
        event EventHandler<UIEventArgs> Zoneflag86;
        event EventHandler<UIEventArgs> Zoneflag87;
        event EventHandler<UIEventArgs> Zoneflag88;
        event EventHandler<UIEventArgs> Zoneflag89;
        event EventHandler<UIEventArgs> Zoneflag90;
        event EventHandler<UIEventArgs> Zoneflag91;
        event EventHandler<UIEventArgs> Zoneflag92;
        event EventHandler<UIEventArgs> Zoneflag93;
        event EventHandler<UIEventArgs> Zoneflag94;
        event EventHandler<UIEventArgs> Zoneflag95;
        event EventHandler<UIEventArgs> Zoneflag96;
        event EventHandler<UIEventArgs> Zoneflag97;
        event EventHandler<UIEventArgs> Zoneflag98;
        event EventHandler<UIEventArgs> Zoneflag99;
        event EventHandler<UIEventArgs> Zoneflag100;
        event EventHandler<UIEventArgs> Zoneflag101;
        event EventHandler<UIEventArgs> Zoneflag102;
        event EventHandler<UIEventArgs> Zoneflag103;
        event EventHandler<UIEventArgs> Zoneflag104;
        event EventHandler<UIEventArgs> Zoneflag105;
        event EventHandler<UIEventArgs> Zoneflag106;
        event EventHandler<UIEventArgs> Zoneflag107;
        event EventHandler<UIEventArgs> Zoneflag108;
        event EventHandler<UIEventArgs> Zoneflag109;
        event EventHandler<UIEventArgs> Zoneflag110;
        event EventHandler<UIEventArgs> Zoneflag111;
        event EventHandler<UIEventArgs> Zoneflag112;
        event EventHandler<UIEventArgs> Zoneflag113;
        event EventHandler<UIEventArgs> Zoneflag114;
        event EventHandler<UIEventArgs> Zoneflag115;
        event EventHandler<UIEventArgs> Zoneflag116;
        event EventHandler<UIEventArgs> Zoneflag117;
        event EventHandler<UIEventArgs> Zoneflag118;
        event EventHandler<UIEventArgs> Zoneflag119;
        event EventHandler<UIEventArgs> Zoneflag120;
        event EventHandler<UIEventArgs> Zoneflag121;
        event EventHandler<UIEventArgs> Zoneflag122;
        event EventHandler<UIEventArgs> Zoneflag123;
        event EventHandler<UIEventArgs> Zoneflag124;
        event EventHandler<UIEventArgs> Zoneflag125;
        event EventHandler<UIEventArgs> Zoneflag126;
        event EventHandler<UIEventArgs> Zoneflag127;
        event EventHandler<UIEventArgs> Zoneflag128;
        event EventHandler<UIEventArgs> Zoneflag129;
        event EventHandler<UIEventArgs> Zoneflag130;
        event EventHandler<UIEventArgs> Zoneflag131;
        event EventHandler<UIEventArgs> Zoneflag132;
        event EventHandler<UIEventArgs> Zoneflag133;
        event EventHandler<UIEventArgs> Zoneflag134;
        event EventHandler<UIEventArgs> Zoneflag135;
        event EventHandler<UIEventArgs> Zoneflag136;
        event EventHandler<UIEventArgs> Zoneflag137;
        event EventHandler<UIEventArgs> Zoneflag138;
        event EventHandler<UIEventArgs> Zoneflag139;
        event EventHandler<UIEventArgs> Zoneflag140;
        event EventHandler<UIEventArgs> Zoneflag141;
        event EventHandler<UIEventArgs> Zoneflag142;
        event EventHandler<UIEventArgs> Zoneflag143;
        event EventHandler<UIEventArgs> Zoneflag144;
        event EventHandler<UIEventArgs> Zoneflag145;
        event EventHandler<UIEventArgs> Zoneflag146;
        event EventHandler<UIEventArgs> Zoneflag147;
        event EventHandler<UIEventArgs> Zoneflag148;
        event EventHandler<UIEventArgs> Zoneflag149;
        event EventHandler<UIEventArgs> Zoneflag150;
        event EventHandler<UIEventArgs> Zoneflag151;
        event EventHandler<UIEventArgs> Zoneflag152;
        event EventHandler<UIEventArgs> Zoneflag153;
        event EventHandler<UIEventArgs> Zoneflag154;
        event EventHandler<UIEventArgs> Zoneflag155;
        event EventHandler<UIEventArgs> Zoneflag156;
        event EventHandler<UIEventArgs> Zoneflag157;
        event EventHandler<UIEventArgs> Zoneflag158;
        event EventHandler<UIEventArgs> Zoneflag159;
        event EventHandler<UIEventArgs> Zoneflag160;
        event EventHandler<UIEventArgs> Zoneflag161;
        event EventHandler<UIEventArgs> Zoneflag162;
        event EventHandler<UIEventArgs> Zoneflag163;
        event EventHandler<UIEventArgs> Zoneflag164;
        event EventHandler<UIEventArgs> Zoneflag165;
        event EventHandler<UIEventArgs> Zoneflag166;
        event EventHandler<UIEventArgs> Zoneflag167;
        event EventHandler<UIEventArgs> Zoneflag168;
        event EventHandler<UIEventArgs> Zoneflag169;
        event EventHandler<UIEventArgs> Zoneflag170;
        event EventHandler<UIEventArgs> Zoneflag171;
        event EventHandler<UIEventArgs> Zoneflag172;
        event EventHandler<UIEventArgs> Zoneflag173;
        event EventHandler<UIEventArgs> Zoneflag174;
        event EventHandler<UIEventArgs> Zoneflag175;
        event EventHandler<UIEventArgs> Zoneflag176;
        event EventHandler<UIEventArgs> Zoneflag177;
        event EventHandler<UIEventArgs> Zoneflag178;
        event EventHandler<UIEventArgs> Zoneflag179;
        event EventHandler<UIEventArgs> Zoneflag180;
        event EventHandler<UIEventArgs> Zoneflag181;
        event EventHandler<UIEventArgs> Zoneflag182;
        event EventHandler<UIEventArgs> Zoneflag183;
        event EventHandler<UIEventArgs> Zoneflag184;
        event EventHandler<UIEventArgs> Zoneflag185;
        event EventHandler<UIEventArgs> Zoneflag186;
        event EventHandler<UIEventArgs> Zoneflag187;
        event EventHandler<UIEventArgs> Zoneflag188;
        event EventHandler<UIEventArgs> Zoneflag189;
        event EventHandler<UIEventArgs> Zoneflag190;
        event EventHandler<UIEventArgs> Zoneflag191;
        event EventHandler<UIEventArgs> Zoneflag192;
        event EventHandler<UIEventArgs> Zoneflag193;
        event EventHandler<UIEventArgs> Zoneflag194;
        event EventHandler<UIEventArgs> Zoneflag195;
        event EventHandler<UIEventArgs> Zoneflag196;
        event EventHandler<UIEventArgs> Zoneflag197;
        event EventHandler<UIEventArgs> Zoneflag198;
        event EventHandler<UIEventArgs> Zoneflag199;
        event EventHandler<UIEventArgs> Zoneflag200;
        event EventHandler<UIEventArgs> Zoneflag201;
        event EventHandler<UIEventArgs> Zoneflag202;
        event EventHandler<UIEventArgs> Zoneflag203;
        event EventHandler<UIEventArgs> Zoneflag204;
        event EventHandler<UIEventArgs> Zoneflag205;
        event EventHandler<UIEventArgs> Zoneflag206;
        event EventHandler<UIEventArgs> Zoneflag207;
        event EventHandler<UIEventArgs> Zoneflag208;
        event EventHandler<UIEventArgs> Zoneflag209;
        event EventHandler<UIEventArgs> Zoneflag210;
        event EventHandler<UIEventArgs> Zoneflag211;
        event EventHandler<UIEventArgs> Zoneflag212;
        event EventHandler<UIEventArgs> Zoneflag213;
        event EventHandler<UIEventArgs> Zoneflag214;
        event EventHandler<UIEventArgs> Zoneflag215;
        event EventHandler<UIEventArgs> Zoneflag216;
        event EventHandler<UIEventArgs> Zoneflag217;
        event EventHandler<UIEventArgs> Zoneflag218;
        event EventHandler<UIEventArgs> Zoneflag219;
        event EventHandler<UIEventArgs> Zoneflag220;
        event EventHandler<UIEventArgs> Zoneflag221;
        event EventHandler<UIEventArgs> Zoneflag222;
        event EventHandler<UIEventArgs> Zoneflag223;
        event EventHandler<UIEventArgs> Zoneflag224;
        event EventHandler<UIEventArgs> Zoneflag225;
        event EventHandler<UIEventArgs> Zoneflag226;
        event EventHandler<UIEventArgs> Zoneflag227;
        event EventHandler<UIEventArgs> Zoneflag228;
        event EventHandler<UIEventArgs> Zoneflag229;
        event EventHandler<UIEventArgs> Zoneflag230;
        event EventHandler<UIEventArgs> Zoneflag231;
        event EventHandler<UIEventArgs> Zoneflag232;
        event EventHandler<UIEventArgs> Zoneflag233;
        event EventHandler<UIEventArgs> Zoneflag234;
        event EventHandler<UIEventArgs> Zoneflag235;
        event EventHandler<UIEventArgs> Zoneflag236;
        event EventHandler<UIEventArgs> Zoneflag237;
        event EventHandler<UIEventArgs> Zoneflag238;
        event EventHandler<UIEventArgs> Zoneflag239;
        event EventHandler<UIEventArgs> Zoneflag240;
        event EventHandler<UIEventArgs> Zoneflag241;
        event EventHandler<UIEventArgs> Zoneflag242;
        event EventHandler<UIEventArgs> Zoneflag243;
        event EventHandler<UIEventArgs> Zoneflag244;
        event EventHandler<UIEventArgs> Zoneflag245;
        event EventHandler<UIEventArgs> Zoneflag246;
        event EventHandler<UIEventArgs> Zoneflag247;
        event EventHandler<UIEventArgs> Zoneflag248;
        event EventHandler<UIEventArgs> Zoneflag249;
        event EventHandler<UIEventArgs> Zoneflag250;


    }

    public delegate void ZonerenameBoolInputSigDelegate(BoolInputSig boolInputSig, IZonerename zonerename);

    internal class Zonerename : IZonerename, IDisposable
    {
        #region Standard CH5 Component members

        private ComponentMediator ComponentMediator { get; set; }

        public object UserObject { get; set; }

        public uint ControlJoinId { get; private set; }

        private IList<BasicTriListWithSmartObject> _devices;
        public IList<BasicTriListWithSmartObject> Devices { get { return _devices; } }

        #endregion

        #region Joins

        private static class Joins
        {
            internal static class Booleans
            {
                public const uint Zoneflag1 = 1;
                public const uint Zoneflag2 = 2;
                public const uint Zoneflag3 = 3;
                public const uint Zoneflag4 = 4;
                public const uint Zoneflag5 = 5;
                public const uint Zoneflag6 = 6;
                public const uint Zoneflag7 = 7;
                public const uint Zoneflag8 = 8;
                public const uint Zoneflag9 = 9;
                public const uint Zoneflag10 = 10;
                public const uint Zoneflag11 = 11;
                public const uint Zoneflag12 = 12;
                public const uint Zoneflag13 = 13;
                public const uint Zoneflag14 = 14;
                public const uint Zoneflag15 = 15;
                public const uint Zoneflag16 = 16;
                public const uint Zoneflag17 = 17;
                public const uint Zoneflag18 = 18;
                public const uint Zoneflag19 = 19;
                public const uint Zoneflag20 = 20;
                public const uint Zoneflag21 = 21;
                public const uint Zoneflag22 = 22;
                public const uint Zoneflag23 = 23;
                public const uint Zoneflag24 = 24;
                public const uint Zoneflag25 = 25;
                public const uint Zoneflag26 = 26;
                public const uint Zoneflag27 = 27;
                public const uint Zoneflag28 = 28;
                public const uint Zoneflag29 = 29;
                public const uint Zoneflag30 = 30;
                public const uint Zoneflag31 = 31;
                public const uint Zoneflag32 = 32;
                public const uint Zoneflag33 = 33;
                public const uint Zoneflag34 = 34;
                public const uint Zoneflag35 = 35;
                public const uint Zoneflag36 = 36;
                public const uint Zoneflag37 = 37;
                public const uint Zoneflag38 = 38;
                public const uint Zoneflag39 = 39;
                public const uint Zoneflag40 = 40;
                public const uint Zoneflag41 = 41;
                public const uint Zoneflag42 = 42;
                public const uint Zoneflag43 = 43;
                public const uint Zoneflag44 = 44;
                public const uint Zoneflag45 = 45;
                public const uint Zoneflag46 = 46;
                public const uint Zoneflag47 = 47;
                public const uint Zoneflag48 = 48;
                public const uint Zoneflag49 = 49;
                public const uint Zoneflag50 = 50;
                public const uint Zoneflag51 = 51;
                public const uint Zoneflag52 = 52;
                public const uint Zoneflag53 = 53;
                public const uint Zoneflag54 = 54;
                public const uint Zoneflag55 = 55;
                public const uint Zoneflag56 = 56;
                public const uint Zoneflag57 = 57;
                public const uint Zoneflag58 = 58;
                public const uint Zoneflag59 = 59;
                public const uint Zoneflag60 = 60;
                public const uint Zoneflag61 = 61;
                public const uint Zoneflag62 = 62;
                public const uint Zoneflag63 = 63;
                public const uint Zoneflag64 = 64;
                public const uint Zoneflag65 = 65;
                public const uint Zoneflag66 = 66;
                public const uint Zoneflag67 = 67;
                public const uint Zoneflag68 = 68;
                public const uint Zoneflag69 = 69;
                public const uint Zoneflag70 = 70;
                public const uint Zoneflag71 = 71;
                public const uint Zoneflag72 = 72;
                public const uint Zoneflag73 = 73;
                public const uint Zoneflag74 = 74;
                public const uint Zoneflag75 = 75;
                public const uint Zoneflag76 = 76;
                public const uint Zoneflag77 = 77;
                public const uint Zoneflag78 = 78;
                public const uint Zoneflag79 = 79;
                public const uint Zoneflag80 = 80;
                public const uint Zoneflag81 = 81;
                public const uint Zoneflag82 = 82;
                public const uint Zoneflag83 = 83;
                public const uint Zoneflag84 = 84;
                public const uint Zoneflag85 = 85;
                public const uint Zoneflag86 = 86;
                public const uint Zoneflag87 = 87;
                public const uint Zoneflag88 = 88;
                public const uint Zoneflag89 = 89;
                public const uint Zoneflag90 = 90;
                public const uint Zoneflag91 = 91;
                public const uint Zoneflag92 = 92;
                public const uint Zoneflag93 = 93;
                public const uint Zoneflag94 = 94;
                public const uint Zoneflag95 = 95;
                public const uint Zoneflag96 = 96;
                public const uint Zoneflag97 = 97;
                public const uint Zoneflag98 = 98;
                public const uint Zoneflag99 = 99;
                public const uint Zoneflag100 = 100;
                public const uint Zoneflag101 = 101;
                public const uint Zoneflag102 = 102;
                public const uint Zoneflag103 = 103;
                public const uint Zoneflag104 = 104;
                public const uint Zoneflag105 = 105;
                public const uint Zoneflag106 = 106;
                public const uint Zoneflag107 = 107;
                public const uint Zoneflag108 = 108;
                public const uint Zoneflag109 = 109;
                public const uint Zoneflag110 = 110;
                public const uint Zoneflag111 = 111;
                public const uint Zoneflag112 = 112;
                public const uint Zoneflag113 = 113;
                public const uint Zoneflag114 = 114;
                public const uint Zoneflag115 = 115;
                public const uint Zoneflag116 = 116;
                public const uint Zoneflag117 = 117;
                public const uint Zoneflag118 = 118;
                public const uint Zoneflag119 = 119;
                public const uint Zoneflag120 = 120;
                public const uint Zoneflag121 = 121;
                public const uint Zoneflag122 = 122;
                public const uint Zoneflag123 = 123;
                public const uint Zoneflag124 = 124;
                public const uint Zoneflag125 = 125;
                public const uint Zoneflag126 = 126;
                public const uint Zoneflag127 = 127;
                public const uint Zoneflag128 = 128;
                public const uint Zoneflag129 = 129;
                public const uint Zoneflag130 = 130;
                public const uint Zoneflag131 = 131;
                public const uint Zoneflag132 = 132;
                public const uint Zoneflag133 = 133;
                public const uint Zoneflag134 = 134;
                public const uint Zoneflag135 = 135;
                public const uint Zoneflag136 = 136;
                public const uint Zoneflag137 = 137;
                public const uint Zoneflag138 = 138;
                public const uint Zoneflag139 = 139;
                public const uint Zoneflag140 = 140;
                public const uint Zoneflag141 = 141;
                public const uint Zoneflag142 = 142;
                public const uint Zoneflag143 = 143;
                public const uint Zoneflag144 = 144;
                public const uint Zoneflag145 = 145;
                public const uint Zoneflag146 = 146;
                public const uint Zoneflag147 = 147;
                public const uint Zoneflag148 = 148;
                public const uint Zoneflag149 = 149;
                public const uint Zoneflag150 = 150;
                public const uint Zoneflag151 = 151;
                public const uint Zoneflag152 = 152;
                public const uint Zoneflag153 = 153;
                public const uint Zoneflag154 = 154;
                public const uint Zoneflag155 = 155;
                public const uint Zoneflag156 = 156;
                public const uint Zoneflag157 = 157;
                public const uint Zoneflag158 = 158;
                public const uint Zoneflag159 = 159;
                public const uint Zoneflag160 = 160;
                public const uint Zoneflag161 = 161;
                public const uint Zoneflag162 = 162;
                public const uint Zoneflag163 = 163;
                public const uint Zoneflag164 = 164;
                public const uint Zoneflag165 = 165;
                public const uint Zoneflag166 = 166;
                public const uint Zoneflag167 = 167;
                public const uint Zoneflag168 = 168;
                public const uint Zoneflag169 = 169;
                public const uint Zoneflag170 = 170;
                public const uint Zoneflag171 = 171;
                public const uint Zoneflag172 = 172;
                public const uint Zoneflag173 = 173;
                public const uint Zoneflag174 = 174;
                public const uint Zoneflag175 = 175;
                public const uint Zoneflag176 = 176;
                public const uint Zoneflag177 = 177;
                public const uint Zoneflag178 = 178;
                public const uint Zoneflag179 = 179;
                public const uint Zoneflag180 = 180;
                public const uint Zoneflag181 = 181;
                public const uint Zoneflag182 = 182;
                public const uint Zoneflag183 = 183;
                public const uint Zoneflag184 = 184;
                public const uint Zoneflag185 = 185;
                public const uint Zoneflag186 = 186;
                public const uint Zoneflag187 = 187;
                public const uint Zoneflag188 = 188;
                public const uint Zoneflag189 = 189;
                public const uint Zoneflag190 = 190;
                public const uint Zoneflag191 = 191;
                public const uint Zoneflag192 = 192;
                public const uint Zoneflag193 = 193;
                public const uint Zoneflag194 = 194;
                public const uint Zoneflag195 = 195;
                public const uint Zoneflag196 = 196;
                public const uint Zoneflag197 = 197;
                public const uint Zoneflag198 = 198;
                public const uint Zoneflag199 = 199;
                public const uint Zoneflag200 = 200;
                public const uint Zoneflag201 = 201;
                public const uint Zoneflag202 = 202;
                public const uint Zoneflag203 = 203;
                public const uint Zoneflag204 = 204;
                public const uint Zoneflag205 = 205;
                public const uint Zoneflag206 = 206;
                public const uint Zoneflag207 = 207;
                public const uint Zoneflag208 = 208;
                public const uint Zoneflag209 = 209;
                public const uint Zoneflag210 = 210;
                public const uint Zoneflag211 = 211;
                public const uint Zoneflag212 = 212;
                public const uint Zoneflag213 = 213;
                public const uint Zoneflag214 = 214;
                public const uint Zoneflag215 = 215;
                public const uint Zoneflag216 = 216;
                public const uint Zoneflag217 = 217;
                public const uint Zoneflag218 = 218;
                public const uint Zoneflag219 = 219;
                public const uint Zoneflag220 = 220;
                public const uint Zoneflag221 = 221;
                public const uint Zoneflag222 = 222;
                public const uint Zoneflag223 = 223;
                public const uint Zoneflag224 = 224;
                public const uint Zoneflag225 = 225;
                public const uint Zoneflag226 = 226;
                public const uint Zoneflag227 = 227;
                public const uint Zoneflag228 = 228;
                public const uint Zoneflag229 = 229;
                public const uint Zoneflag230 = 230;
                public const uint Zoneflag231 = 231;
                public const uint Zoneflag232 = 232;
                public const uint Zoneflag233 = 233;
                public const uint Zoneflag234 = 234;
                public const uint Zoneflag235 = 235;
                public const uint Zoneflag236 = 236;
                public const uint Zoneflag237 = 237;
                public const uint Zoneflag238 = 238;
                public const uint Zoneflag239 = 239;
                public const uint Zoneflag240 = 240;
                public const uint Zoneflag241 = 241;
                public const uint Zoneflag242 = 242;
                public const uint Zoneflag243 = 243;
                public const uint Zoneflag244 = 244;
                public const uint Zoneflag245 = 245;
                public const uint Zoneflag246 = 246;
                public const uint Zoneflag247 = 247;
                public const uint Zoneflag248 = 248;
                public const uint Zoneflag249 = 249;
                public const uint Zoneflag250 = 250;

            }
        }

        #endregion

        #region Construction and Initialization

        internal Zonerename(ComponentMediator componentMediator, uint controlJoinId)
        {
            ComponentMediator = componentMediator;
            Initialize(controlJoinId);
        }

        private void Initialize(uint controlJoinId)
        {
            ControlJoinId = controlJoinId; 
 
            _devices = new List<BasicTriListWithSmartObject>(); 
 
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag1, onZoneflag1);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag2, onZoneflag2);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag3, onZoneflag3);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag4, onZoneflag4);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag5, onZoneflag5);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag6, onZoneflag6);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag7, onZoneflag7);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag8, onZoneflag8);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag9, onZoneflag9);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag10, onZoneflag10);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag11, onZoneflag11);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag12, onZoneflag12);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag13, onZoneflag13);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag14, onZoneflag14);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag15, onZoneflag15);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag16, onZoneflag16);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag17, onZoneflag17);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag18, onZoneflag18);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag19, onZoneflag19);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag20, onZoneflag20);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag21, onZoneflag21);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag22, onZoneflag22);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag23, onZoneflag23);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag24, onZoneflag24);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag25, onZoneflag25);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag26, onZoneflag26);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag27, onZoneflag27);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag28, onZoneflag28);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag29, onZoneflag29);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag30, onZoneflag30);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag31, onZoneflag31);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag32, onZoneflag32);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag33, onZoneflag33);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag34, onZoneflag34);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag35, onZoneflag35);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag36, onZoneflag36);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag37, onZoneflag37);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag38, onZoneflag38);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag39, onZoneflag39);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag40, onZoneflag40);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag41, onZoneflag41);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag42, onZoneflag42);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag43, onZoneflag43);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag44, onZoneflag44);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag45, onZoneflag45);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag46, onZoneflag46);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag47, onZoneflag47);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag48, onZoneflag48);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag49, onZoneflag49);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag50, onZoneflag50);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag51, onZoneflag51);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag52, onZoneflag52);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag53, onZoneflag53);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag54, onZoneflag54);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag55, onZoneflag55);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag56, onZoneflag56);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag57, onZoneflag57);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag58, onZoneflag58);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag59, onZoneflag59);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag60, onZoneflag60);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag61, onZoneflag61);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag62, onZoneflag62);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag63, onZoneflag63);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag64, onZoneflag64);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag65, onZoneflag65);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag66, onZoneflag66);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag67, onZoneflag67);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag68, onZoneflag68);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag69, onZoneflag69);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag70, onZoneflag70);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag71, onZoneflag71);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag72, onZoneflag72);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag73, onZoneflag73);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag74, onZoneflag74);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag75, onZoneflag75);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag76, onZoneflag76);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag77, onZoneflag77);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag78, onZoneflag78);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag79, onZoneflag79);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag80, onZoneflag80);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag81, onZoneflag81);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag82, onZoneflag82);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag83, onZoneflag83);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag84, onZoneflag84);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag85, onZoneflag85);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag86, onZoneflag86);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag87, onZoneflag87);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag88, onZoneflag88);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag89, onZoneflag89);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag90, onZoneflag90);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag91, onZoneflag91);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag92, onZoneflag92);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag93, onZoneflag93);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag94, onZoneflag94);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag95, onZoneflag95);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag96, onZoneflag96);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag97, onZoneflag97);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag98, onZoneflag98);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag99, onZoneflag99);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag100, onZoneflag100);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag101, onZoneflag101);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag102, onZoneflag102);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag103, onZoneflag103);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag104, onZoneflag104);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag105, onZoneflag105);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag106, onZoneflag106);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag107, onZoneflag107);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag108, onZoneflag108);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag109, onZoneflag109);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag110, onZoneflag110);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag111, onZoneflag111);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag112, onZoneflag112);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag113, onZoneflag113);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag114, onZoneflag114);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag115, onZoneflag115);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag116, onZoneflag116);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag117, onZoneflag117);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag118, onZoneflag118);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag119, onZoneflag119);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag120, onZoneflag120);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag121, onZoneflag121);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag122, onZoneflag122);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag123, onZoneflag123);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag124, onZoneflag124);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag125, onZoneflag125);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag126, onZoneflag126);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag127, onZoneflag127);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag128, onZoneflag128);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag129, onZoneflag129);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag130, onZoneflag130);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag131, onZoneflag131);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag132, onZoneflag132);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag133, onZoneflag133);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag134, onZoneflag134);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag135, onZoneflag135);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag136, onZoneflag136);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag137, onZoneflag137);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag138, onZoneflag138);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag139, onZoneflag139);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag140, onZoneflag140);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag141, onZoneflag141);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag142, onZoneflag142);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag143, onZoneflag143);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag144, onZoneflag144);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag145, onZoneflag145);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag146, onZoneflag146);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag147, onZoneflag147);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag148, onZoneflag148);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag149, onZoneflag149);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag150, onZoneflag150);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag151, onZoneflag151);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag152, onZoneflag152);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag153, onZoneflag153);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag154, onZoneflag154);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag155, onZoneflag155);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag156, onZoneflag156);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag157, onZoneflag157);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag158, onZoneflag158);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag159, onZoneflag159);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag160, onZoneflag160);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag161, onZoneflag161);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag162, onZoneflag162);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag163, onZoneflag163);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag164, onZoneflag164);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag165, onZoneflag165);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag166, onZoneflag166);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag167, onZoneflag167);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag168, onZoneflag168);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag169, onZoneflag169);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag170, onZoneflag170);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag171, onZoneflag171);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag172, onZoneflag172);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag173, onZoneflag173);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag174, onZoneflag174);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag175, onZoneflag175);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag176, onZoneflag176);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag177, onZoneflag177);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag178, onZoneflag178);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag179, onZoneflag179);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag180, onZoneflag180);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag181, onZoneflag181);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag182, onZoneflag182);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag183, onZoneflag183);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag184, onZoneflag184);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag185, onZoneflag185);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag186, onZoneflag186);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag187, onZoneflag187);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag188, onZoneflag188);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag189, onZoneflag189);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag190, onZoneflag190);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag191, onZoneflag191);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag192, onZoneflag192);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag193, onZoneflag193);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag194, onZoneflag194);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag195, onZoneflag195);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag196, onZoneflag196);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag197, onZoneflag197);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag198, onZoneflag198);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag199, onZoneflag199);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag200, onZoneflag200);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag201, onZoneflag201);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag202, onZoneflag202);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag203, onZoneflag203);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag204, onZoneflag204);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag205, onZoneflag205);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag206, onZoneflag206);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag207, onZoneflag207);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag208, onZoneflag208);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag209, onZoneflag209);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag210, onZoneflag210);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag211, onZoneflag211);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag212, onZoneflag212);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag213, onZoneflag213);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag214, onZoneflag214);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag215, onZoneflag215);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag216, onZoneflag216);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag217, onZoneflag217);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag218, onZoneflag218);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag219, onZoneflag219);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag220, onZoneflag220);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag221, onZoneflag221);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag222, onZoneflag222);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag223, onZoneflag223);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag224, onZoneflag224);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag225, onZoneflag225);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag226, onZoneflag226);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag227, onZoneflag227);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag228, onZoneflag228);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag229, onZoneflag229);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag230, onZoneflag230);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag231, onZoneflag231);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag232, onZoneflag232);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag233, onZoneflag233);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag234, onZoneflag234);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag235, onZoneflag235);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag236, onZoneflag236);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag237, onZoneflag237);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag238, onZoneflag238);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag239, onZoneflag239);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag240, onZoneflag240);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag241, onZoneflag241);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag242, onZoneflag242);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag243, onZoneflag243);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag244, onZoneflag244);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag245, onZoneflag245);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag246, onZoneflag246);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag247, onZoneflag247);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag248, onZoneflag248);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag249, onZoneflag249);
            ComponentMediator.ConfigureBooleanEvent(controlJoinId, Joins.Booleans.Zoneflag250, onZoneflag250);

        }

        public void AddDevice(BasicTriListWithSmartObject device)
        {
            Devices.Add(device);
            ComponentMediator.HookSmartObjectEvents(device.SmartObjects[ControlJoinId]);
        }

        public void RemoveDevice(BasicTriListWithSmartObject device)
        {
            Devices.Remove(device);
            ComponentMediator.UnHookSmartObjectEvents(device.SmartObjects[ControlJoinId]);
        }

        #endregion

        #region CH5 Contract

        public event EventHandler<UIEventArgs> Zoneflag1;
        private void onZoneflag1(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag1;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag2;
        private void onZoneflag2(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag2;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag3;
        private void onZoneflag3(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag3;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag4;
        private void onZoneflag4(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag4;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag5;
        private void onZoneflag5(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag5;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag6;
        private void onZoneflag6(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag6;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag7;
        private void onZoneflag7(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag7;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag8;
        private void onZoneflag8(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag8;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag9;
        private void onZoneflag9(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag9;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag10;
        private void onZoneflag10(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag10;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag11;
        private void onZoneflag11(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag11;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag12;
        private void onZoneflag12(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag12;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag13;
        private void onZoneflag13(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag13;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag14;
        private void onZoneflag14(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag14;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag15;
        private void onZoneflag15(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag15;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag16;
        private void onZoneflag16(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag16;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag17;
        private void onZoneflag17(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag17;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag18;
        private void onZoneflag18(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag18;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag19;
        private void onZoneflag19(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag19;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag20;
        private void onZoneflag20(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag20;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag21;
        private void onZoneflag21(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag21;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag22;
        private void onZoneflag22(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag22;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag23;
        private void onZoneflag23(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag23;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag24;
        private void onZoneflag24(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag24;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag25;
        private void onZoneflag25(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag25;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag26;
        private void onZoneflag26(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag26;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag27;
        private void onZoneflag27(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag27;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag28;
        private void onZoneflag28(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag28;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag29;
        private void onZoneflag29(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag29;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag30;
        private void onZoneflag30(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag30;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag31;
        private void onZoneflag31(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag31;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag32;
        private void onZoneflag32(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag32;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag33;
        private void onZoneflag33(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag33;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag34;
        private void onZoneflag34(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag34;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag35;
        private void onZoneflag35(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag35;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag36;
        private void onZoneflag36(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag36;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag37;
        private void onZoneflag37(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag37;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag38;
        private void onZoneflag38(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag38;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag39;
        private void onZoneflag39(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag39;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag40;
        private void onZoneflag40(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag40;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag41;
        private void onZoneflag41(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag41;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag42;
        private void onZoneflag42(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag42;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag43;
        private void onZoneflag43(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag43;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag44;
        private void onZoneflag44(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag44;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag45;
        private void onZoneflag45(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag45;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag46;
        private void onZoneflag46(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag46;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag47;
        private void onZoneflag47(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag47;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag48;
        private void onZoneflag48(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag48;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag49;
        private void onZoneflag49(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag49;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag50;
        private void onZoneflag50(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag50;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag51;
        private void onZoneflag51(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag51;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag52;
        private void onZoneflag52(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag52;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag53;
        private void onZoneflag53(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag53;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag54;
        private void onZoneflag54(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag54;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag55;
        private void onZoneflag55(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag55;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag56;
        private void onZoneflag56(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag56;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag57;
        private void onZoneflag57(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag57;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag58;
        private void onZoneflag58(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag58;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag59;
        private void onZoneflag59(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag59;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag60;
        private void onZoneflag60(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag60;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag61;
        private void onZoneflag61(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag61;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag62;
        private void onZoneflag62(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag62;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag63;
        private void onZoneflag63(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag63;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag64;
        private void onZoneflag64(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag64;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag65;
        private void onZoneflag65(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag65;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag66;
        private void onZoneflag66(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag66;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag67;
        private void onZoneflag67(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag67;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag68;
        private void onZoneflag68(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag68;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag69;
        private void onZoneflag69(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag69;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag70;
        private void onZoneflag70(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag70;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag71;
        private void onZoneflag71(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag71;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag72;
        private void onZoneflag72(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag72;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag73;
        private void onZoneflag73(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag73;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag74;
        private void onZoneflag74(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag74;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag75;
        private void onZoneflag75(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag75;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag76;
        private void onZoneflag76(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag76;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag77;
        private void onZoneflag77(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag77;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag78;
        private void onZoneflag78(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag78;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag79;
        private void onZoneflag79(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag79;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag80;
        private void onZoneflag80(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag80;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag81;
        private void onZoneflag81(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag81;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag82;
        private void onZoneflag82(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag82;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag83;
        private void onZoneflag83(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag83;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag84;
        private void onZoneflag84(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag84;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag85;
        private void onZoneflag85(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag85;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag86;
        private void onZoneflag86(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag86;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag87;
        private void onZoneflag87(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag87;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag88;
        private void onZoneflag88(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag88;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag89;
        private void onZoneflag89(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag89;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag90;
        private void onZoneflag90(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag90;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag91;
        private void onZoneflag91(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag91;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag92;
        private void onZoneflag92(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag92;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag93;
        private void onZoneflag93(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag93;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag94;
        private void onZoneflag94(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag94;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag95;
        private void onZoneflag95(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag95;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag96;
        private void onZoneflag96(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag96;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag97;
        private void onZoneflag97(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag97;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag98;
        private void onZoneflag98(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag98;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag99;
        private void onZoneflag99(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag99;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag100;
        private void onZoneflag100(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag100;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag101;
        private void onZoneflag101(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag101;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag102;
        private void onZoneflag102(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag102;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag103;
        private void onZoneflag103(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag103;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag104;
        private void onZoneflag104(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag104;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag105;
        private void onZoneflag105(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag105;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag106;
        private void onZoneflag106(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag106;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag107;
        private void onZoneflag107(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag107;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag108;
        private void onZoneflag108(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag108;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag109;
        private void onZoneflag109(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag109;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag110;
        private void onZoneflag110(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag110;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag111;
        private void onZoneflag111(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag111;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag112;
        private void onZoneflag112(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag112;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag113;
        private void onZoneflag113(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag113;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag114;
        private void onZoneflag114(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag114;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag115;
        private void onZoneflag115(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag115;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag116;
        private void onZoneflag116(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag116;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag117;
        private void onZoneflag117(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag117;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag118;
        private void onZoneflag118(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag118;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag119;
        private void onZoneflag119(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag119;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag120;
        private void onZoneflag120(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag120;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag121;
        private void onZoneflag121(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag121;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag122;
        private void onZoneflag122(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag122;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag123;
        private void onZoneflag123(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag123;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag124;
        private void onZoneflag124(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag124;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag125;
        private void onZoneflag125(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag125;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag126;
        private void onZoneflag126(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag126;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag127;
        private void onZoneflag127(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag127;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag128;
        private void onZoneflag128(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag128;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag129;
        private void onZoneflag129(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag129;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag130;
        private void onZoneflag130(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag130;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag131;
        private void onZoneflag131(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag131;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag132;
        private void onZoneflag132(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag132;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag133;
        private void onZoneflag133(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag133;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag134;
        private void onZoneflag134(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag134;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag135;
        private void onZoneflag135(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag135;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag136;
        private void onZoneflag136(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag136;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag137;
        private void onZoneflag137(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag137;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag138;
        private void onZoneflag138(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag138;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag139;
        private void onZoneflag139(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag139;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag140;
        private void onZoneflag140(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag140;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag141;
        private void onZoneflag141(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag141;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag142;
        private void onZoneflag142(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag142;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag143;
        private void onZoneflag143(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag143;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag144;
        private void onZoneflag144(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag144;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag145;
        private void onZoneflag145(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag145;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag146;
        private void onZoneflag146(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag146;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag147;
        private void onZoneflag147(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag147;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag148;
        private void onZoneflag148(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag148;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag149;
        private void onZoneflag149(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag149;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag150;
        private void onZoneflag150(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag150;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag151;
        private void onZoneflag151(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag151;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag152;
        private void onZoneflag152(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag152;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag153;
        private void onZoneflag153(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag153;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag154;
        private void onZoneflag154(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag154;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag155;
        private void onZoneflag155(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag155;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag156;
        private void onZoneflag156(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag156;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag157;
        private void onZoneflag157(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag157;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag158;
        private void onZoneflag158(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag158;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag159;
        private void onZoneflag159(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag159;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag160;
        private void onZoneflag160(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag160;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag161;
        private void onZoneflag161(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag161;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag162;
        private void onZoneflag162(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag162;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag163;
        private void onZoneflag163(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag163;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag164;
        private void onZoneflag164(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag164;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag165;
        private void onZoneflag165(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag165;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag166;
        private void onZoneflag166(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag166;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag167;
        private void onZoneflag167(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag167;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag168;
        private void onZoneflag168(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag168;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag169;
        private void onZoneflag169(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag169;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag170;
        private void onZoneflag170(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag170;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag171;
        private void onZoneflag171(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag171;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag172;
        private void onZoneflag172(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag172;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag173;
        private void onZoneflag173(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag173;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag174;
        private void onZoneflag174(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag174;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag175;
        private void onZoneflag175(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag175;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag176;
        private void onZoneflag176(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag176;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag177;
        private void onZoneflag177(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag177;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag178;
        private void onZoneflag178(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag178;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag179;
        private void onZoneflag179(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag179;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag180;
        private void onZoneflag180(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag180;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag181;
        private void onZoneflag181(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag181;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag182;
        private void onZoneflag182(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag182;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag183;
        private void onZoneflag183(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag183;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag184;
        private void onZoneflag184(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag184;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag185;
        private void onZoneflag185(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag185;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag186;
        private void onZoneflag186(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag186;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag187;
        private void onZoneflag187(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag187;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag188;
        private void onZoneflag188(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag188;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag189;
        private void onZoneflag189(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag189;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag190;
        private void onZoneflag190(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag190;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag191;
        private void onZoneflag191(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag191;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag192;
        private void onZoneflag192(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag192;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag193;
        private void onZoneflag193(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag193;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag194;
        private void onZoneflag194(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag194;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag195;
        private void onZoneflag195(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag195;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag196;
        private void onZoneflag196(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag196;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag197;
        private void onZoneflag197(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag197;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag198;
        private void onZoneflag198(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag198;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag199;
        private void onZoneflag199(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag199;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag200;
        private void onZoneflag200(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag200;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag201;
        private void onZoneflag201(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag201;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag202;
        private void onZoneflag202(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag202;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag203;
        private void onZoneflag203(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag203;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag204;
        private void onZoneflag204(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag204;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag205;
        private void onZoneflag205(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag205;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag206;
        private void onZoneflag206(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag206;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag207;
        private void onZoneflag207(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag207;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag208;
        private void onZoneflag208(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag208;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag209;
        private void onZoneflag209(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag209;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag210;
        private void onZoneflag210(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag210;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag211;
        private void onZoneflag211(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag211;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag212;
        private void onZoneflag212(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag212;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag213;
        private void onZoneflag213(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag213;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag214;
        private void onZoneflag214(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag214;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag215;
        private void onZoneflag215(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag215;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag216;
        private void onZoneflag216(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag216;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag217;
        private void onZoneflag217(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag217;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag218;
        private void onZoneflag218(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag218;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag219;
        private void onZoneflag219(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag219;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag220;
        private void onZoneflag220(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag220;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag221;
        private void onZoneflag221(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag221;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag222;
        private void onZoneflag222(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag222;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag223;
        private void onZoneflag223(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag223;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag224;
        private void onZoneflag224(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag224;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag225;
        private void onZoneflag225(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag225;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag226;
        private void onZoneflag226(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag226;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag227;
        private void onZoneflag227(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag227;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag228;
        private void onZoneflag228(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag228;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag229;
        private void onZoneflag229(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag229;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag230;
        private void onZoneflag230(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag230;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag231;
        private void onZoneflag231(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag231;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag232;
        private void onZoneflag232(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag232;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag233;
        private void onZoneflag233(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag233;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag234;
        private void onZoneflag234(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag234;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag235;
        private void onZoneflag235(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag235;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag236;
        private void onZoneflag236(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag236;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag237;
        private void onZoneflag237(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag237;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag238;
        private void onZoneflag238(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag238;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag239;
        private void onZoneflag239(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag239;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag240;
        private void onZoneflag240(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag240;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag241;
        private void onZoneflag241(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag241;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag242;
        private void onZoneflag242(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag242;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag243;
        private void onZoneflag243(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag243;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag244;
        private void onZoneflag244(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag244;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag245;
        private void onZoneflag245(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag245;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag246;
        private void onZoneflag246(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag246;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag247;
        private void onZoneflag247(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag247;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag248;
        private void onZoneflag248(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag248;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag249;
        private void onZoneflag249(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag249;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }

        public event EventHandler<UIEventArgs> Zoneflag250;
        private void onZoneflag250(SmartObjectEventArgs eventArgs)
        {
            EventHandler<UIEventArgs> handler = Zoneflag250;
            if (handler != null)
                handler(this, UIEventArgs.CreateEventArgs(eventArgs));
        }


        #endregion

        #region Overrides

        public override int GetHashCode()
        {
            return (int)ControlJoinId;
        }

        public override string ToString()
        {
            return string.Format("Contract: {0} Component: {1} HashCode: {2} {3}", "Zonerename", GetType().Name, GetHashCode(), UserObject != null ? "UserObject: " + UserObject : null);
        }

        #endregion

        #region IDisposable

        public bool IsDisposed { get; set; }

        public void Dispose()
        {
            if (IsDisposed)
                return;

            IsDisposed = true;

            Zoneflag1 = null;
            Zoneflag2 = null;
            Zoneflag3 = null;
            Zoneflag4 = null;
            Zoneflag5 = null;
            Zoneflag6 = null;
            Zoneflag7 = null;
            Zoneflag8 = null;
            Zoneflag9 = null;
            Zoneflag10 = null;
            Zoneflag11 = null;
            Zoneflag12 = null;
            Zoneflag13 = null;
            Zoneflag14 = null;
            Zoneflag15 = null;
            Zoneflag16 = null;
            Zoneflag17 = null;
            Zoneflag18 = null;
            Zoneflag19 = null;
            Zoneflag20 = null;
            Zoneflag21 = null;
            Zoneflag22 = null;
            Zoneflag23 = null;
            Zoneflag24 = null;
            Zoneflag25 = null;
            Zoneflag26 = null;
            Zoneflag27 = null;
            Zoneflag28 = null;
            Zoneflag29 = null;
            Zoneflag30 = null;
            Zoneflag31 = null;
            Zoneflag32 = null;
            Zoneflag33 = null;
            Zoneflag34 = null;
            Zoneflag35 = null;
            Zoneflag36 = null;
            Zoneflag37 = null;
            Zoneflag38 = null;
            Zoneflag39 = null;
            Zoneflag40 = null;
            Zoneflag41 = null;
            Zoneflag42 = null;
            Zoneflag43 = null;
            Zoneflag44 = null;
            Zoneflag45 = null;
            Zoneflag46 = null;
            Zoneflag47 = null;
            Zoneflag48 = null;
            Zoneflag49 = null;
            Zoneflag50 = null;
            Zoneflag51 = null;
            Zoneflag52 = null;
            Zoneflag53 = null;
            Zoneflag54 = null;
            Zoneflag55 = null;
            Zoneflag56 = null;
            Zoneflag57 = null;
            Zoneflag58 = null;
            Zoneflag59 = null;
            Zoneflag60 = null;
            Zoneflag61 = null;
            Zoneflag62 = null;
            Zoneflag63 = null;
            Zoneflag64 = null;
            Zoneflag65 = null;
            Zoneflag66 = null;
            Zoneflag67 = null;
            Zoneflag68 = null;
            Zoneflag69 = null;
            Zoneflag70 = null;
            Zoneflag71 = null;
            Zoneflag72 = null;
            Zoneflag73 = null;
            Zoneflag74 = null;
            Zoneflag75 = null;
            Zoneflag76 = null;
            Zoneflag77 = null;
            Zoneflag78 = null;
            Zoneflag79 = null;
            Zoneflag80 = null;
            Zoneflag81 = null;
            Zoneflag82 = null;
            Zoneflag83 = null;
            Zoneflag84 = null;
            Zoneflag85 = null;
            Zoneflag86 = null;
            Zoneflag87 = null;
            Zoneflag88 = null;
            Zoneflag89 = null;
            Zoneflag90 = null;
            Zoneflag91 = null;
            Zoneflag92 = null;
            Zoneflag93 = null;
            Zoneflag94 = null;
            Zoneflag95 = null;
            Zoneflag96 = null;
            Zoneflag97 = null;
            Zoneflag98 = null;
            Zoneflag99 = null;
            Zoneflag100 = null;
            Zoneflag101 = null;
            Zoneflag102 = null;
            Zoneflag103 = null;
            Zoneflag104 = null;
            Zoneflag105 = null;
            Zoneflag106 = null;
            Zoneflag107 = null;
            Zoneflag108 = null;
            Zoneflag109 = null;
            Zoneflag110 = null;
            Zoneflag111 = null;
            Zoneflag112 = null;
            Zoneflag113 = null;
            Zoneflag114 = null;
            Zoneflag115 = null;
            Zoneflag116 = null;
            Zoneflag117 = null;
            Zoneflag118 = null;
            Zoneflag119 = null;
            Zoneflag120 = null;
            Zoneflag121 = null;
            Zoneflag122 = null;
            Zoneflag123 = null;
            Zoneflag124 = null;
            Zoneflag125 = null;
            Zoneflag126 = null;
            Zoneflag127 = null;
            Zoneflag128 = null;
            Zoneflag129 = null;
            Zoneflag130 = null;
            Zoneflag131 = null;
            Zoneflag132 = null;
            Zoneflag133 = null;
            Zoneflag134 = null;
            Zoneflag135 = null;
            Zoneflag136 = null;
            Zoneflag137 = null;
            Zoneflag138 = null;
            Zoneflag139 = null;
            Zoneflag140 = null;
            Zoneflag141 = null;
            Zoneflag142 = null;
            Zoneflag143 = null;
            Zoneflag144 = null;
            Zoneflag145 = null;
            Zoneflag146 = null;
            Zoneflag147 = null;
            Zoneflag148 = null;
            Zoneflag149 = null;
            Zoneflag150 = null;
            Zoneflag151 = null;
            Zoneflag152 = null;
            Zoneflag153 = null;
            Zoneflag154 = null;
            Zoneflag155 = null;
            Zoneflag156 = null;
            Zoneflag157 = null;
            Zoneflag158 = null;
            Zoneflag159 = null;
            Zoneflag160 = null;
            Zoneflag161 = null;
            Zoneflag162 = null;
            Zoneflag163 = null;
            Zoneflag164 = null;
            Zoneflag165 = null;
            Zoneflag166 = null;
            Zoneflag167 = null;
            Zoneflag168 = null;
            Zoneflag169 = null;
            Zoneflag170 = null;
            Zoneflag171 = null;
            Zoneflag172 = null;
            Zoneflag173 = null;
            Zoneflag174 = null;
            Zoneflag175 = null;
            Zoneflag176 = null;
            Zoneflag177 = null;
            Zoneflag178 = null;
            Zoneflag179 = null;
            Zoneflag180 = null;
            Zoneflag181 = null;
            Zoneflag182 = null;
            Zoneflag183 = null;
            Zoneflag184 = null;
            Zoneflag185 = null;
            Zoneflag186 = null;
            Zoneflag187 = null;
            Zoneflag188 = null;
            Zoneflag189 = null;
            Zoneflag190 = null;
            Zoneflag191 = null;
            Zoneflag192 = null;
            Zoneflag193 = null;
            Zoneflag194 = null;
            Zoneflag195 = null;
            Zoneflag196 = null;
            Zoneflag197 = null;
            Zoneflag198 = null;
            Zoneflag199 = null;
            Zoneflag200 = null;
            Zoneflag201 = null;
            Zoneflag202 = null;
            Zoneflag203 = null;
            Zoneflag204 = null;
            Zoneflag205 = null;
            Zoneflag206 = null;
            Zoneflag207 = null;
            Zoneflag208 = null;
            Zoneflag209 = null;
            Zoneflag210 = null;
            Zoneflag211 = null;
            Zoneflag212 = null;
            Zoneflag213 = null;
            Zoneflag214 = null;
            Zoneflag215 = null;
            Zoneflag216 = null;
            Zoneflag217 = null;
            Zoneflag218 = null;
            Zoneflag219 = null;
            Zoneflag220 = null;
            Zoneflag221 = null;
            Zoneflag222 = null;
            Zoneflag223 = null;
            Zoneflag224 = null;
            Zoneflag225 = null;
            Zoneflag226 = null;
            Zoneflag227 = null;
            Zoneflag228 = null;
            Zoneflag229 = null;
            Zoneflag230 = null;
            Zoneflag231 = null;
            Zoneflag232 = null;
            Zoneflag233 = null;
            Zoneflag234 = null;
            Zoneflag235 = null;
            Zoneflag236 = null;
            Zoneflag237 = null;
            Zoneflag238 = null;
            Zoneflag239 = null;
            Zoneflag240 = null;
            Zoneflag241 = null;
            Zoneflag242 = null;
            Zoneflag243 = null;
            Zoneflag244 = null;
            Zoneflag245 = null;
            Zoneflag246 = null;
            Zoneflag247 = null;
            Zoneflag248 = null;
            Zoneflag249 = null;
            Zoneflag250 = null;
        }

        #endregion

    }
}
