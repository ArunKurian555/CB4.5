import { CUSTOM_ELEMENTS_SCHEMA, Component } from '@angular/core';

@Component({
  selector: 'app-sub2',
  standalone: true,
  imports: [],
  templateUrl: './sub2.component.html',
  styleUrl: './sub2.component.scss',
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class Sub2Component {

}
