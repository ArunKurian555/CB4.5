import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ChRouteServiceService {
  active: number;
  constructor() { }
}
