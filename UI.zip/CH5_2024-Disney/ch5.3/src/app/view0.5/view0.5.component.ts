import { Component } from '@angular/core';

@Component({
  selector: 'app-view0.5',
  standalone: true,
  imports: [],
  templateUrl: './view0.5.component.html',
  styleUrl: './view0.5.component.scss'
})
export class View05Component {

}
